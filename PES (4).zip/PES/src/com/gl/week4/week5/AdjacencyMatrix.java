package com.gl.week4.week5;

import java.util.ArrayList;

public class AdjacencyMatrix {
    public static void main(String[] args) {
        AdGraph adGraph =  new AdGraph(5);
        adGraph.addEdge(0,4);
        adGraph.addEdge(1,4);
        adGraph.addEdge(2,4);
        adGraph.addEdge(4,3);
        adGraph.addEdge(3,4);
        adGraph.addEdge(2,1);
        adGraph.addNode();
        adGraph.addEdge(0,5);
        adGraph.addEdge(1,5);
        adGraph.addEdge(2,5);
        adGraph.addEdge(4,5);


        adGraph.printG();
        System.out.println(adGraph.checkEdge(0,3));
        System.out.println(adGraph.checkEdge(3,4));
    }
}

class AdGraph{
    int[][] adj;
    int nodes;

    public AdGraph(int nodes) {
        this.nodes = nodes;
        this.adj = new int[nodes][nodes];
    }

    public void addEdge(int s,int d){
        adj[s][d] = 1;
    }

    public void addNode(){
        int[][] nArr = new int[nodes+1][nodes+1];
        for (int i = 0; i < nodes; i++) {
            for (int j = 0; j < nodes; j++) {
                nArr[i][j] = adj[i][j];
            }
        }
        adj=nArr;
    }

    public boolean checkEdge(int s,int d){
        if (adj[s][d] == 1){
            return true;
        } else {
            return false;
        }
    }

    public void printG(){
        for (int i = 0; i < adj.length; i++) {
            for (int j = 0; j < adj.length; j++) {
                if (adj[i][j] == 1){
                    System.out.println(i+"->"+j);
                }
            }
        }
    }
}
