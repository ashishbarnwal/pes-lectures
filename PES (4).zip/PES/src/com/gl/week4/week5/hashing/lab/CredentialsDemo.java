package com.gl.week4.week5.hashing.lab;

import java.util.Scanner;
public class CredentialsDemo {
    private static final int TABLE_SIZE = 10; // Size of the hash table
    private Entry[] table;
    public CredentialsDemo() {
        table = new Entry[TABLE_SIZE];
    }
    // Inner class representing an entry in the hash table
    private static class Entry {
        String username;
        String password;
        Entry next;
        Entry(String username, String password) {
            this.username = username;
            this.password = password;
            this.next = null;
        }
    }
    // Hash function to calculate the index based on the username
    private int hash(String username) {
        int hash = 0;
        for (char c : username.toCharArray()) {
            hash += c;
        } return Math.abs(hash) %
                TABLE_SIZE;
    }
    // Method to store the username and password in the hash table
    public void storeCredentials(String username, String password) {
        int index = hash(username);
        Entry newEntry = new Entry(username, password);
        if (table[index] == null) {
            table[index] = newEntry;
        } else {
            Entry current = table[index];
            while (current.next != null) {
                current = current.next;
            }
            current.next = newEntry;
        }
    }
    // Method to search and validate the username and password
    public String verifyCredentials(String username, String password) {
        int index = hash(username);
        if (table[index] != null) {
            Entry current = table[index];
            while (current != null) {
                if (current.username.equals(username)) {
                    if (current.password.equals(password)) {
                        return "Access Granted";
                    } else {
                        return "Invalid Password";
                    }
                }
                current = current.next;
            }
        } return "";

    }
    public static void main(String[] args) {
        String[] usernames = {
                "jSmith23", "mJohnson77", "aBrown91", "eWilson42", "lThompson55",
                "user123", "johnDoe", "soccerfan", "kittylover", "gamer123"
        };
        String[] passwords = {
                "P@ssw0rd!", "Secure&Str0ng!", "Protect3d&Safe!", "2FaCt0r#Auth!",
                "IronCl@d#Defence!",
                "password123", "johnDoe123", "soccerfan1", "ilovekittens", "gaming123"
        };
        CredentialsDemo credentialsDemo = new CredentialsDemo();
        Scanner sc = new Scanner(System.in);
// Storing credentials
        for (int i=0; i<usernames.length; i++) {
            credentialsDemo.storeCredentials(usernames[i], passwords[i]);
        }
// Searching and validating credentials
        System.out.println(credentialsDemo.verifyCredentials(sc.next(), sc.next()));
    }
}
