package com.gl.week4.week5.hashing;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class HashTable {
    ArrayList<LinkedList<Employee>> hashtable;
    int capacity;

    public HashTable(int capacity) {
        this.capacity = capacity;
        this.hashtable = new ArrayList<>(capacity);
        for (int i = 0; i < capacity; i++) {
            hashtable.add(new LinkedList<Employee>());
        }
    }

    public Employee get(int empId) {
        int key = getIndex(empId);
        LinkedList<Employee> ee = hashtable.get(key);
        for (int i = 0; i < ee.size(); i++) {
            if (ee.get(i).empId == empId){
                return ee.get(i);
            }
        }
        return null;
    }

    public void put(Employee employee) {
        int key = getIndex(employee.empId);
        LinkedList<Employee> temp = hashtable.get(key);
        temp.add(employee);
        }

    public void delete(int empId) {
        int index =getIndex(empId);
            LinkedList<Employee> ll = hashtable.get(index);
            for (int i = 0; i < ll.size(); i++) {
                Employee temp = ll.get(i);
                if (temp.empId == empId){
                    ll.remove(temp);
                    System.out.println("deleted");
                    return;
                }
            }
            System.out.println("not present");
        }

    public int getIndex(int empId) {
         return empId%capacity;
    }

    public void printHash(){
        for (LinkedList<Employee> ll : hashtable){
            for (int i = 0; i < ll.size(); i++) {
                System.out.println(ll.get(i));
            }
        }
    }
}
