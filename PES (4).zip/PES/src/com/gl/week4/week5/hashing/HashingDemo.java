package com.gl.week4.week5.hashing;

import java.util.Arrays;
import java.util.PriorityQueue;

public class HashingDemo {
    public static void main(String[] args) {
        System.out.println(anagramHash("a#$b.c&d","dcb.&$#a"));
        System.out.println(System.currentTimeMillis());
        int[] ropes = {4,3,2,6};
        System.out.println(ropeCost(ropes));
    }
    public static boolean anagram(String s1, String s2){
        char[] chars = s1.toCharArray();
        char[] chars2 = s2.toCharArray();

        Arrays.sort(chars);
        Arrays.sort(chars2);
        return Arrays.equals(chars, chars2);
    }


    public static boolean anagramHash(String s1, String s2){
        int[] arr = new int[256];
        for (int i = 0; i < s1.length(); i++) {
            int temp = s1.charAt(i);
            arr[temp]++;
        }

        for (int i = 0; i < s2.length(); i++) {
            int temp = s2.charAt(i);
            arr[temp]--;
        }

        for (int i = 0; i < 256; i++) {
            if (arr[i] != 0){
                return false;
            }
        }
        return true;
    }

    public static boolean anagramHash26(String s1, String s2) {
        int[] arr = new int[26];
        for (int i = 0; i < s1.length(); i++) {
            int temp = s1.charAt(i) - 'a';
            arr[temp]++;
        }

        for (int i = 0; i < s2.length(); i++) {
            int temp = s1.charAt(i) - 'a';
            arr[temp]--;
        }

        for (int i = 0; i < 26; i++) {
            if (arr[i] != 0) {
                return false;
            }
        }
        return true;
    }

    public static int ropeCost(int[] ropes){
        int cost =0;
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for (int i:ropes){
            minHeap.add(i);
        }
        while (minHeap.size()>1){
            int f = minHeap.remove();
            int s = minHeap.remove();
            int newRope = s+f;
            cost+=newRope;
            minHeap.add(newRope);
        }
        return cost;
    }

}
