package com.gl.week4.week5.hashing;

import java.util.*;

public class EmpHashDemo {
    public static void main(String[] args) {
        Employee e = new Employee(123,"john","mathew",23,"neeladri road bangalore");
        Employee e1 = new Employee(124,"Manjunath","fname",21,"road bangalore");
        Employee e2 = new Employee(125,"Santosh","fname",23,"neeladri  bangalore");
        Employee e3 = new Employee(125,"Nagashree","Illa",26,"bangalore");
        Employee e4 = new Employee(127,"Swathi","reddy",23,"e city road bangalore");
        Employee e5 = new Employee(128,"swati","kumari",26,"koramangla road bangalore");
        Employee e6 = new Employee(129,"Jack","Mathew",23,"delhi");
        Employee e7 = new Employee(113,"Preet","Singh",23,"noida");
        Employee e8 = new Employee(127,"Kuljeet","Kaur",29,"Punjab");

        Employee e9 = new Employee(127,"Kuljeet","Kaur",29,"Punjab");

        Set<Employee> set = new HashSet<>();

        set.add(e1);
        set.add(e2);
        set.add(e3);
        set.add(e4);
        set.add(e5);

        List<Employee> l = new ArrayList<>(set);

        Collections.sort(l, (o1, o2) -> o1.getAddress().compareTo(o2.getAddress()));
        System.out.println("sorted on the basis of address");
        System.out.println(l);

        Map<Employee, String> map =  new TreeMap<>();
     /*   map.put(null, "ashish");
        map.put(null, "ashish");
        map.put(null, "ashish");*/

        List<Employee> eList = Arrays.asList(e8,e2,e3,e4,null, null);
        System.out.println(eList.contains(e9));

        System.out.println("checking equality "+e8.equals(e9));

        HashTable hashTable = new HashTable(10);


        hashTable.put(e);
        hashTable.put(e2);
     /*   hashTable.put(e2);
        hashTable.put(e8);
        hashTable.put(e7);*/
        hashTable.printHash();

    /*    System.out.println(hashTable.get(129));
        System.out.println(hashTable.get(113));*/

        hashTable.delete(123);
        hashTable.printHash();

    }
}
