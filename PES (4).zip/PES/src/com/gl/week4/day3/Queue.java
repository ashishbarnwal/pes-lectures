package com.gl.week4.day3;

import java.util.ArrayDeque;
import java.util.Deque;

public class Queue {
    public static void main(String[] args) {
        /*Queue q = new Queue(10);
        q.deque();
        q.enque(1);
        q.enque(2);
        q.enque(3);
        q.enque(4);
        q.show();
        q.deque();
        q.show();
        System.out.println();*/

        Deque<Integer> dq = new ArrayDeque<>();
        dq.addFirst(1);
        dq.addLast(2);
        dq.addFirst(3);
        dq.addFirst(4);
        // 4 3 1 2
        dq.addLast(10);
        dq.addLast(40);

        // 4 3 1 2 10 40

        System.out.println(dq.removeFirst());
        System.out.println(dq.removeLast());
    }
    private int[] arr;
    private int size;
    private int front;
    private int rear;

    public Queue(int size) {
        this.size = size;
        this.arr = new int[size];
        this.front = 0;
        this.rear = -1;
    }

    // enque

    public void enque(int val){
        if (rear == size-1){
            System.out.println("queue is full");
            return;
        }
        arr[++rear] = val;
    }

    // is Empty

    public boolean isEmpty(){
        if (front > rear){
            return true;
        } else {
            return false;
        }
    }

    // is Full
    public boolean isFull(){
        if (rear == size-1){
            return true;
        }
        return false;
    }

    // deque
    public int deque(){
        if (isEmpty()){
            System.out.println("queue is empty ");
            return 0;
        } else {
            /*int temp = arr[front];
            front++;
            return temp;*/
            return arr[front++];
        }
    }

    // front

    public int getFront(){
        return front;
    }

    // rear
    public int getRear(){
        return rear;
    }

    // show
    public void show(){
        if (isEmpty()){
            System.out.println("queue is empty");
        } else {
            for (int i = front; i <=rear ; i++) {
                System.out.print(arr[i]+ " ");
            }
        }
    }
}
