package com.gl.week4.day1;

public class DoublyLL {
    DNode head;
    DNode tail;

    public DoublyLL(DNode head, DNode tail) {
        this.head = head;
        this.tail = tail;
    }

    public static void main(String[] args) {
        DNode head = new DNode(1);
        DNode tail = new DNode(5);
        DNode sec = new DNode(2);
        DNode thi = new DNode(3);
        DNode four = new DNode(4);
        head.next = sec;
        sec.next = thi;
        sec.prev = head;
        thi.next = four;
        thi.prev = sec;
        four.next = tail;
        four.prev = thi;
        tail.prev = four;
        DoublyLL dll = new DoublyLL(head, tail);
        traverseForward(dll);
    }

    public static void traverseForward(DoublyLL doublyLL){
        DNode temp = doublyLL.head;
        while (temp != null){
            System.out.println(temp.data);
            temp = temp.next;
        }
    }

    public static void traverseBack(DoublyLL doublyLL){
        DNode temp = doublyLL.tail;
        while (temp != null){
            System.out.println(temp.data);
            temp = temp.prev;
        }
    }
}


class DNode{
    int data;
    DNode next;
    DNode prev;

    public DNode(int data) {
        this.data = data;
    }
}
