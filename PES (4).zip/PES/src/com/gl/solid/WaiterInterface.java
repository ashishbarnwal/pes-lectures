package com.gl.solid;

public interface WaiterInterface {
    void servesFood();
    void takesOrder();
}

interface CookInterface{
    void cooksFood();
}


class Waiter implements WaiterInterface{

    @Override
    public void servesFood() {

    }

    @Override
    public void takesOrder() {

    }
}

class Cook implements  CookInterface{

    @Override
    public void cooksFood() {

    }
}