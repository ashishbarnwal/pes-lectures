package com.gl.week7.day2;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class OutputStreamReader {
    public static void main(String[] args) {
        try {
            FileOutputStream fo = new FileOutputStream("output.txt");
            for (int i = 48; i <57 ; i++) {
                fo.write(i);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
