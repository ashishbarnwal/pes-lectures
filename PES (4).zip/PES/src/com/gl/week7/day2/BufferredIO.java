package com.gl.week7.day2;

import java.io.*;

public class BufferredIO {
    public static void main(String[] args) {
        try {

            FileOutputStream fo =  new FileOutputStream("fio.txt");
            BufferedOutputStream bo = new BufferedOutputStream(fo);
            for (int i = 97; i <=122 ; i++) {
                bo.write(i);
            }
            bo.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            FileInputStream fi =  new FileInputStream("fio.txt");
            BufferedInputStream bi = new BufferedInputStream(fi);
            int c;
            while ((c=bi.read())!=-1){
                System.out.print((char)c);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
