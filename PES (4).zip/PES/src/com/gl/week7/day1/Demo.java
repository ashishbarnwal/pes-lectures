package com.gl.week7.day1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Demo {
    public static void main(String[] args) throws Exception {
        method2();
    }

    public static void method2() throws Exception{
        method1();
    }

    public static void method1() throws IOException{
        int[] arr = {1, 2, 3, 4};
        System.out.println(arr[10]);
        FileInputStream fi = new FileInputStream("a.txt");
        for (int i = 0; i < 100; i++) {
            System.out.println(i);
        }
        // System.exit(0);
    }
}