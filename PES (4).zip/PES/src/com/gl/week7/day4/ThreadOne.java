package com.gl.week7.day4;

public class ThreadOne extends Thread{
    Printer p;
    String name;

    public ThreadOne(Printer p, String name) {
        this.p = p;
        this.name=name;
    }

    public void run(){
        try {
            p.show(name);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
