package com.gl.week9.dao;

import com.gl.week9.connection.Conection;
import com.gl.week9.model.Customer;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CustomerDao {
    Conection conection;

    public CustomerDao() {
        this.conection = new Conection();
    }

    public List<Customer> getCustomers() throws SQLException, ClassNotFoundException {
        String s = "select * from cust_details";
        Statement st = conection.getCon().createStatement();
        ResultSet rs = st.executeQuery(s);
        List<Customer> customers = new ArrayList<>();
        while (rs.next()){
            Customer customer = new Customer();
            customer.setId(rs.getInt(1));
            customer.setName(rs.getString(2));
            customer.setGender(rs.getString(3).charAt(0));
            customers.add(customer);
        }
        return customers;
    }
    public Customer getCustomerById(Integer id) throws SQLException, ClassNotFoundException {
        String s = "select * from cust_details where id = "+id;
        Statement st = conection.getCon().createStatement();
        ResultSet rs = st.executeQuery(s);
        Customer customer = new Customer();
        while (rs.next()){
            customer.setId(rs.getInt(1));
            customer.setName(rs.getString(2));
            customer.setGender(rs.getString(3).charAt(0));
        }
        return customer;
    }
}
