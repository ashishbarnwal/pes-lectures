package com.gl.week9;

import com.gl.week9.connection.Conection;

import java.sql.*;

public class PSDemo {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Conection c = new Conection();
        Connection con = c.getCon();
      /*  PreparedStatement stmt=con.prepareStatement("insert into Emp values(?,?)");
        PreparedStatement stmt=con.prepareStatement("delete from emp where id=?");
       */
               PreparedStatement stmt=con.prepareStatement("select * from cust_details");


        PreparedStatement ps=con.prepareStatement("update cust_details set name=? where id=?");
        ps.setString(1, "Amit");
        ps.setInt(2,1);
        ps.executeUpdate();
        ResultSet resultSet = stmt.executeQuery();
        ResultSetMetaData rsmd = resultSet.getMetaData();
        DatabaseMetaData dbmd = con.getMetaData();
        System.out.println(dbmd.getMaxColumnsInIndex()+" "+dbmd.getMaxColumnsInIndex());
        while (resultSet.next()){
            System.out.println(resultSet.getInt(1));
        }
    }
}
