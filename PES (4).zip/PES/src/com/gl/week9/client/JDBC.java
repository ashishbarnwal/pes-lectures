package com.gl.week9.client;

import com.gl.week9.model.Customer;
import com.gl.week9.service.CustomerService;

import java.util.List;
import java.util.Scanner;

public class JDBC {
    public static void main(String[] args) throws Exception {
        System.out.println("Inserting records into the table...");
    /*    String sql = "INSERT INTO cust_details VALUES (100, 'Zara', 'F')";
        stmt.executeUpdate(sql);
        sql = "INSERT INTO cust_details VALUES (101, 'Mahnaz', 'F')";
        stmt.executeUpdate(sql);

        System.out.println("Inserted records into the table...");
        */
        System.out.println("Getting all customer");
        CustomerService cs = new CustomerService();
        List<Customer> customers = cs.getCustomers();
        for (Customer customer: customers){
            System.out.println(customer);
        }

        System.out.println("give the id to see the data ");
        Scanner sc = new Scanner(System.in);
        int i = sc.nextInt();
        Customer customerById = cs.getCustomerById(i);
        System.out.println(customerById);
    }
}
