package com.gl.week13;

public class OddEvenDemo {

    int counter = 1;

    static int N;

    public void printOddNumber()
    {
        synchronized (this)
        {
            while (counter < N) {

                while (counter % 2 == 0) {

                    try {
                        wait();
                    }
                    catch (
                            InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                System.out.print(counter + " ");
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                counter++;

                notify();
            }
        }
    }

    public void printEvenNumber()
    {
        synchronized (this)
        {
            while (counter < N) {

                while (counter % 2 == 1) {

                    try {
                        wait();
                    }
                    catch (
                            InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                System.out.print(
                        counter + " ");
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                counter++;

                notify();
            }
        }
    }

    public static void main(String[] args)
    {
        N = 100;

        OddEvenDemo oddEvenDemo = new OddEvenDemo();

        Thread t1 = new Thread(new Runnable() {
            public void run()
            {
                oddEvenDemo.printEvenNumber();
            }
        });

        Thread t2 = new Thread(new Runnable() {
            public void run()
            {
                oddEvenDemo.printOddNumber();
            }
        });

        t1.start();
        t2.start();
    }
}
