package com.gl.week13;

import com.gl.Manufacturer;
import com.gl.Watch;
import com.gl.week4.week5.hashing.Employee;

import java.util.*;
import java.util.concurrent.*;

public class SpringDemo {
    public static void main(String[] args) throws Exception {
       // Manufacturer manufacturer = new Manufacturer();
        Manufacturer manufacturer = new Manufacturer("abc","adgh", true);
        System.out.println(manufacturer);
        Watch watch = new Watch(1111, manufacturer,1000.0f);
        Watch cloned = watch.clone();
        cloned.getManufacturer().setIsRegistered(false);
        System.out.println(watch.getManufacturer());
        System.out.println(cloned);
        System.out.println(watch.getManufacturer()==cloned.getManufacturer());
        ExecutorService service = Executors.newFixedThreadPool(100);
        A a = new A();
        Vector<Integer> v = new Vector<>();
        v.add(1);
        v.add(2);
        v.add(3);
        v.add(4);
        v.add(5);
        Enumeration<Integer> e = v.elements();
        while (e.hasMoreElements()){
            System.out.println(e.nextElement());
        }
        List<Integer> l = new ArrayList<>();
        l.add(1);
        l.add(2);
        l.add(3);
        l.add(4);
        l.add(5);
        Iterator<Integer> i = l.iterator();
        while (i.hasNext()){
            int val = i.next();
            if (val%2 == 0)
                l.add(val);
            else {
                System.out.println(val);
            }
        }
        System.out.println(l);
        List<Integer> al = new ArrayList<>();
        al.add(1);
        al.add(2);
        al.add(3);
        al.add(4);
        al.add(5);
        ListIterator<Integer> li = al.listIterator();
        ExecutorService serv = Executors.newFixedThreadPool(3);
        MyRunnable[] jobs = {
                new MyRunnable("first"),
                new MyRunnable("second"),
                new MyRunnable("third"),
                new MyRunnable("fourth"),
                new MyRunnable("fifth"),
                new MyRunnable("six"),
                new MyRunnable("seven"),
        };
        for (Runnable r : jobs){
            serv.submit(r);
        }
        serv.shutdown();
        MyCallable m = new MyCallable();
        System.out.println(m.call());

        ArrayBlockingQueue<Integer> q = new ArrayBlockingQueue<>(5);
    }
}

class MyRunnable implements Runnable{
    String name;

    public MyRunnable(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println("task assigned");
    }
}

interface Demo{
    void m1();
    default void m2(){
        System.out.println("I am breaking java interface contract");
    }
    static void m3(){
        System.out.println("I am breaking java interface contract");
    }
}

class A implements Demo{

    @Override
    public void m1() {
        System.out.println("m1");
    }
}

class MyCallable implements Callable{

    @Override
    public Object call() throws Exception {
        Integer s=0;
        System.out.println("doing task");
        for (int i = 0; i < 100; i++) {
            s+=i;
        }
        return s;
    }
}