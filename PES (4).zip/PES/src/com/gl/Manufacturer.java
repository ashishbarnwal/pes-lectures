package com.gl;

import lombok.*;

import java.util.Date;
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Manufacturer implements Cloneable{
    private String name;
    private String ownerName;
    private Boolean isRegistered;

    public Manufacturer clone() throws CloneNotSupportedException {
        return (Manufacturer) super.clone();
    }
}
