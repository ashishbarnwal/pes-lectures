package com.gl.ashish.day8;

public class OptimizedBubble {
    int[] arr = {7, 4, 9, 2, 5};;
    int pointer= arr.length-1;
    boolean status = false;
    public static void main(String[] args) {
        OptimizedBubble ob = new OptimizedBubble();
        ob.sort();
        for (int i = 0; i < ob.arr.length; i++) {
            System.out.println(ob.arr[i]);
        }
    }
    public void sort() {
        while(status == false) {
            status = true;
            for(int j = 0;j<pointer;j++) {
                if(arr[j]>arr[j+1]) {
                    arr[j] += arr[j+1];
                    arr[j+1] = arr[j]-arr[j+1];
                    arr[j] -= arr[j+1];
                    status = false;
                }
            }
            pointer--;
        }
    }
}

/*
  4, 7, 9, 2, 5
4, 7, 2, 9, 5
* */