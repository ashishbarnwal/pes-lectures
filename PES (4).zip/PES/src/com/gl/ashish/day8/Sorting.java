package com.gl.ashish.day8;

import java.util.Arrays;

public class Sorting {
    public static void main(String[] args) {
        int[] arr = {7, 4, 9, 2, 5};
        quickSort(arr,0,arr.length-1);
        Arrays.sort(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }

    public static int[] bubble(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        return arr;
    }

    public static int[] selection(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            int small = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j] < arr[small]) {
                    small = j;
                }
            }
            int temp = arr[small];
            arr[small] = arr[i];
            arr[i] = temp;
        }
        return arr;
    }

    public static int[] insertion(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            int j = i;
            int val = arr[i];
            while (j > 0 && val < arr[j - 1]) {
                arr[j] = arr[j - 1];
                j--;
            }
            arr[j] = val;
        }
        return arr;
    }

    public static int[] mergeSort(int[] arr, int st, int end) {
        if (st<end){
            int mid = st + (end - st) / 2;
            mergeSort(arr, st, mid);
            mergeSort(arr, mid + 1, end);
            merge(arr, st, mid, end);
            return arr;
        }
        return arr;
    }

    private static void merge(int[] arr, int st, int mid, int end) {
        int n1 = mid - st + 1;
        int n2 = end - mid;
        int[] l = new int[n1];
        int[] r = new int[n2];
        for (int i = 0; i < n1; i++) {
            l[i] = arr[st + i];
        }
        for (int i = 0; i < n2; i++) {
            r[i] = arr[mid + i + 1];
        }
        int i = 0;
        int j = 0;
        int k = st;
        while (i < n1 && j < n2) {
            if (l[i] < r[j]) {
                arr[k] = l[i];
                i++;
            } else {
                arr[k] = r[j];
                j++;
            }
            k++;
        }
        while (i<n1){
            arr[k] = l[i];
            k++;
            i++;
        }
        while (j<n2){
            arr[k] = r[j];
            k++;
            j++;
        }
    }

    static void quickSort(int[] arr, int st, int end){
        if (st<end){
            int pivot = findPartition(arr,st,end);
            quickSort(arr, st, pivot-1);
            quickSort(arr, pivot+1, end);
        }
    }

    public static int findPartition (int a[], int start, int end)
    {
        int pivot = a[end];
        int i = (start - 1);

        for (int j = start; j < end; j++)
        {
            if (a[j] < pivot)
            {
                i++;
                int t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
        }
        int t = a[i+1];
        a[i+1] = a[end];
        a[end] = t;
        return (i + 1);
    }
}
