package com.gl.ashish;

public class First {
    public static void main(String[] args) {
        /*System.out.println("ashish");

        int first = Integer.valueOf("66");
        int a1= 90;
        float f = 123.5f;
        long l =1234567890l;
        char c= (char) a1;
        System.out.println(c);
        char char1 = '3';
        int int1= char1;

        float d = l;

        int gender=0;
        int i =1;*/
        int i=1;
        System.out.println(++i+ i++);
        System.out.println(++i+ ++i);
        System.out.println(i+++ i++);
        System.out.println(i+++ ++i);
    }
}
