package com.gl.ashish.day6;

public class Algorithms {
    public static void main(String[] args) {
        System.out.println(isOdd(3));
    }

    static boolean isOdd(int number) {

        return number == 0 ? false : isEven(Math.abs(number) - 1);

    }

    static boolean isEven(int number) {

        return number == 0 ? true : isOdd(Math.abs(number) - 1);

    }
}
