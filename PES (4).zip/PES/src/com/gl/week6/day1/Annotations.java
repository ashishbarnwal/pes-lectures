package com.gl.week6.day1;

import java.io.IOException;

public class Annotations {
    public static void main(String[] args) {
        Animal a = new Dog();
        a.eatSomething();
        a.m1();
    }
}

abstract class Animal{

    void m1() throws RuntimeException{
        System.out.println("m1 method");
    }

    void eatSomething(){
        System.out.println("basic method");
    }
}

class Dog extends Animal{
    @Override
    void eatSomething(){
        System.out.println("dog is eating");
    }


    void m1() {
        System.out.println("m1 method");
    }
}


// marker annotation
@interface EmptyString{

}
// single value annotation
@interface MyAnnotation{
    int value() default 0;
}


@interface MultiValue{
    int val1();
    String val2() default "ashish";
    String val3();
}