package com.gl.week6.day2;

import java.util.*;

public class Examples {
    public static void main(String[] args) {
        int[] arr = {1,1,2,3,3,4,5,6,6,7,8,8};
        int[] arr1 = {1,1,2,6,6,6,6,6,6,6,8,8};
        majElement(arr1);
        removeDupl(arr);
        String s = "aaabccdeef";
        occurance(s);
        Queue<Integer> queue = new LinkedList<>();
        queue.add(1);
        queue.add(2);
        queue.add(3);
        System.out.println(queue.peek());
        System.out.println(queue.remove());
        List list = new LinkedList(queue);

        Map<String, Integer> map= new HashMap<>();
        System.out.println(map.put("Ram",70));
        map.put("Ravana",102);
        map.put("Sita", 70);
        map.put("Indrajeet",70);
        map.put("Lava",6);
        System.out.println(map.put("Lava",8));
        map.put("Lava",80);
        map.put(null, 100);
        Iterator<Map.Entry<String, Integer>> iterator = map.entrySet().iterator();
        Set<Integer> set =  new HashSet<>();
        set.add(1);
        set.add(2);
        set.add(65);
        set.add(null);
        set.add(5);
        System.out.println(set);
        set.clear();
        System.out.println(set);
        /*System.out.println(set.add(60));
        System.out.println(set.add(70));*/
        String bal ="([[{}]])";
        System.out.println("balanced "+isBalanced(bal));
    }
    public static void removeDupl(int[] arr){
        List<Integer> list = new ArrayList<>();
        for (int i:arr){
            list.add(i);
        }
        Set<Integer> set = new HashSet<>();
        set.addAll(list);
        System.out.println(set);
    }

    public static void majElement(int[] arr){
        Map<Integer, Integer> map = new HashMap<>();
        for (int i:arr){
                map.put(i, map.getOrDefault(i,0)+1);
        }
        for (int key: map.keySet()){
            if (map.get(key) > arr.length/2){
                System.out.println("majority element is "+ key);
                return;
            }
        }
        System.out.println("no majority element");
    }


    public static void occurance(String s){
        Map<Character, Integer> map = new HashMap<>();
        for (char c:s.toCharArray()){
            if (!map.containsKey(c)){
                map.put(c,1);
            } else {
                map.put(c, map.get(c)+1);
            }
        }
        for (Map.Entry<Character, Integer> enrty: map.entrySet()){
            System.out.println(enrty.getKey()+ " occurs "+enrty.getValue()+" many times");
        }
    }

    public static boolean isBalanced(String s){
        Stack<Character> st = new Stack<>();
        for (char c : s.toCharArray()){
            if (c == '(' || c=='{' || c== '['){
                st.push(c);
            } else {
                if (st.empty()){
                    return false;
                } else {
                    char temp = st.peek();
                    if ((c=='(' && temp== ')') ||(c=='{' && temp == '}') ||(c=='[' && temp ==']')){
                        st.pop();
                    }
                }
            }
        }
        return st.isEmpty();
    }
}

class Employee{
    int empId;
    String name;

}