package com.gl.week6.day3;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Labs {
    public static void main(String[] args) {
// 1. Create TreeMap object
        TreeMap<Integer,String> map=new TreeMap<Integer,String>();
// 2. Insert values into Map
        map.put(1, "Puneet");
        map.put(4,"Ravi");
        map.put(2,"Vijay");
        map.put(3,"Rahul");
        map.put(5, "Kiran");
// 3. SubMap operations
        System.out.println("Map is:\t\t"+map);
        System.out.println("Head Map is:\t"+map.headMap(4));
        System.out.println("Tail Map is:\t"+map.tailMap(2));
        System.out.println("Subset Map is:\t"+map.subMap(2, 4));
// 4. Check if the map contains key 3
        System.out.println("\nMap contains key 3:\t"+map.containsKey(3));
// 5. print the map in descending order
        System.out.println("Descending order of the map is:\t"+map.descendingMap());
// 6. Replace value at key 4 with Ankit by passing 3 parameters
        System.out.println("Replaced key value\t"+map.replace(4, "Ravi", "Ankit"));
// 7. Poll first and last entry from the map
        System.out.println("First entry is:\t"+map.pollFirstEntry());
        System.out.println("Last entry is:\t"+map.pollLastEntry());
// 8. Print the map
        System.out.println("\nTree Map after operations is: \n"+map);
    }
}
