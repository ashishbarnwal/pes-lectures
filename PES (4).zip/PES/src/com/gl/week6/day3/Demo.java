package com.gl.week6.day3;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Demo {
    public static void main(String[] args) {
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "Puneet");
        map.put(4,"Ravi");
        map.put(2,"Vijay");
        map.put(3,"Rahul");
        map.put(5, "Kiran");
        System.out.println(map);
        System.out.println(map.get(4));
        System.out.println(map.get(400));
        System.out.println(map.size());
        map.remove(5);
        System.out.println(map);
        System.out.println(map.isEmpty());
        map.clear();
        System.out.println(map);
        for (Map.Entry<Integer, String> entry : map.entrySet()){
            System.out.println(entry.getKey());
            System.out.println(entry.getValue());
        }
        Map<Integer, String> treemap = new TreeMap<>();
        treemap.put(1,"Puneet");
        treemap.put(4,"Ravi");
        treemap.put(2,"Vijay");
        treemap.put(3,"Rahul");
        treemap.put(5, "Kiran");
        System.out.println(treemap);
    }
}
