package com.gl.week6.day4;

public class Generics {
    public static void main(String[] args) {
        Test<Integer> test1 = new Test<>(5);
        Test<String> test2 = new Test<>("ashish");
        Test<Boolean> test3 = new Test<>(true);
        Test<Student> test4 = new Test<>(new Student("132", "john", 29));
        Integer[] arr ={1,2};
        genericMethod(arr);
        String[] arr2 = {"ashish","anish"};
        genericMethod(arr2);
    }

    static  <T> void genericMethod(T[] val){
        for (T v:val){
            System.out.println(v);
        }
    }
}

class Test<T>{
    T value;

    public Test(T value) {
        this.value = value;
    }

    public T getValue() {
        return value;
    }
}



class Test2<T,U>{
    T value;
    U value2;

    public Test2(T value, U value2) {
        this.value = value;
        this.value2= value2;
    }

    public T getValue() {
        return value;
    }
}
