package com.gl;

import com.gl.week6.day1.Collection;
import lombok.ToString;

@ToString
public class Watch implements Cloneable{
    private Integer modelNo;
    private Manufacturer manufacturer;
    private Float price;

    public Watch(Integer modelNo, Manufacturer manufacturer, Float price) {
        this.modelNo = modelNo;
        this.manufacturer = manufacturer;
        this.price = price;
    }

    public Integer getModelNo() {
        return modelNo;
    }

    public void setModelNo(Integer modelNo) {
        this.modelNo = modelNo;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Manufacturer getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(Manufacturer manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Watch clone() throws CloneNotSupportedException {
        Watch watch = (Watch) super.clone();
        Manufacturer clonedManufacturer = watch.getManufacturer().clone();
        watch.setManufacturer(clonedManufacturer);
        return watch;
    }


}
