package com.gl.week8.day1;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Direction {
    static
    {

    }
    public static void main(String[] args) {

        Stream.iterate(1, x -> x + 1).limit(10).forEach(System.out::println);
        List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9);


        List<Integer> list2 = Arrays.asList(5,10,20,50);

        Integer reduce1 = list2.stream().reduce(1, (a, b) -> a * b);
        System.out.println(reduce1);

        int maxSqr = list.stream().filter(no -> no % 2 != 0).map(n -> n * n).max((a,b)-> Integer.compare(a,b)).get();
        System.out.println(maxSqr);
        //1st
        Stream<Integer> limit = list.stream().filter(integer -> integer % 2 != 0).map(a -> a * a).sorted((a, b) -> b - a).limit(1);

        Integer reduce = list.stream().reduce(1, (a, b) -> a * b);
        System.out.println(reduce);
        Direct direct = Direct.NORTH;
        Direct direct1 = Direct.NORTH;

        System.out.println(direct);
        System.out.println(direct.toString().equals("NORTH"));
        System.out.println(direct.equals(direct1));
        BookGenres b = BookGenres.BIOGRAPHIES;
        System.out.println(b.minAgeToRead);

        Optional<String> op = Optional.empty();
        System.out.println(op.isPresent());
        Optional<String> op2 = Optional.of("ashish");
        System.out.println(op2.get());
        Optional<String> op3 = Optional.ofNullable(null);
        if (op3.isPresent()){
            System.out.println(op3.get());
        } else {
            System.out.println("its null");
        }
    }
}


enum Direct {
    SOUTH,
    NORTH,
    EAST,
    WEST;

    // semicolon after the object delaration
}

enum BookGenres{
    BIOGRAPHIES(10),
    FINCTIONAL(14),
    MYTHOLOGY(12),
    KIDSBOOK(4);

    int minAgeToRead;

    BookGenres(int minAgeToRead) {
        this.minAgeToRead = minAgeToRead;
    }
}


