package com.gl.week8.day1;

public class MyThreadDemo {
    public static void main(String[] args) throws InterruptedException {
        MyT mt = new MyT();
        mt.start();
        //Thread.sleep(0,1);
       // mt.join();
        mt.wait();
        System.out.println(mt.i);
    }
}

class MyT extends Thread{
    int i=0;
    public void run(){
        for (int j = 1; j <=10000; j++) {
            i+=j;
        }
        this.notify();
        // millions of lines of code here
    }
}
