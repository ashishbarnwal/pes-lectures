package com.gl.week8.day1;

import java.util.LinkedList;

public class ProdCons {
    public static void main(String[] args) {
        Resource r = new Resource();
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    r.produce();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    r.consume();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        t1.start();
        t2.start();
    }
}

class Resource{
    LinkedList<Integer> list = new LinkedList<>();
    int cap = 5;
    public void produce() throws InterruptedException {
        int val =0;
        while (true){
            synchronized (this){
                while (list.size() == cap)
                    wait();
                System.out.println("produced "+ val);
                list.add(val++);
                notify();
                Thread.sleep(1000);
            }
        }
    }

    public void consume() throws InterruptedException {
        while (true){
            synchronized (this){
                while (list.size() == 0)
                    wait();
                int val = list.remove();
                System.out.println("consumed "+ val);
                notify();
                Thread.sleep(1000);
            }
        }
    }
}