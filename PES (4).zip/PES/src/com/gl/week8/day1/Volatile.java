package com.gl.week8.day1;

public class Volatile {
    public static void main(String[] args) throws InterruptedException {
        VolatileData vData = new VolatileData();
        VThread v = new VThread(vData);
        VThread v2 = new VThread(vData);
        v.start();
        v2.start();
        Thread.sleep(100);
        System.out.println(vData.getCounter());
    }
}

class VThread extends Thread{

    private final VolatileData data;

    VThread(VolatileData v) {
        data=v;
    }

    public void run(){
        for (int i = 0; i < 5; i++) {
          //  System.out.println("old value "+data.getCounter());
            data.increaseCounter();
           // System.out.println("new Value "+data.getCounter());
        }
    }
}


class VolatileData
{
    private int counter = 0;
    public int getCounter()
    {
        return counter;
    }
    public void increaseCounter()
    {
        ++counter;
    }
}