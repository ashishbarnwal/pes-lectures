package com.gl.week8.day1;

public class ITDemo {
    public static void main(String[] args) throws InterruptedException {
        Thread1 thread1 = new Thread1();
        thread1.start();
        Thread.sleep(100);
        // thread1.join();
        synchronized (thread1){
            System.out.println("main thread calling wait method");
            thread1.wait();
        }
        System.out.println("main thread got the notification");
        System.out.println(thread1.total);
    }
}

class Thread1 extends Thread{
    int total = 0;
    public void run(){
        System.out.println("child thread is calculating");
        for (int i = 1; i <= 100; i++) {
            total+=i;
        }
        System.out.println("child thread giving notification after calculation");
        synchronized (this){
            this.notify();
        }
    }
}


