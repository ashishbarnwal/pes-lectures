package com.gl.week8.day1;

public class StaticDemo {
    static int a;
    static
    {
        System.out.println("class is leaded");
        System.out.println("its a static block");
    }

    public static void main(String[] args) {

        Watch w1 = new Watch(100);
        System.out.println(w1.giveId());
        Watch w2 = new Watch(100);
        Watch w3 = new Watch(100);
        System.out.println(w3.giveId());
        Watch w4 = new Watch(100);
        Watch w5 = new Watch(100);
        System.out.println(Watch.count);
    }

    static void m1(){
        System.out.println(a);
    }
}

class Watch{
    @Override
    public String toString() {
        return "Watch{" +
                "id=" + id +
                ", price=" + price +
                '}';
    }

    static int count=0;
    int id;
    int price;

    public int giveId(){
        return count++;
    }

    public Watch(int price) {
        this.price = price;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}