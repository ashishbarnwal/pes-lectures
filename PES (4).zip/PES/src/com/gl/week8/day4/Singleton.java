package com.gl.week8.day4;

public class Singleton {
    static private Singleton o;  // lazy loading
    private Singleton() {
    }

    public static Singleton getSingleton(){
        if (o==null){
            o = new Singleton();
        }
        return o;
    }
}

