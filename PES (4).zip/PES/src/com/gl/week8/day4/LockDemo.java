package com.gl.week8.day4;

import com.gl.ashish.day3.Student;

import java.util.concurrent.locks.ReentrantLock;

public class LockDemo {
    public static void main(String[] args) {
        ReentrantLock lock = new ReentrantLock(true);
        DisplayThread d1 = new DisplayThread("first", lock);
        DisplayThread d2 = new DisplayThread("second", lock);
        DisplayThread d3 = new DisplayThread("third", lock);
        DisplayThread d4 = new DisplayThread("fourth", lock);

        System.out.println(lock.getHoldCount());
        System.out.println(lock.isLocked());
        System.out.println(lock.getHoldCount());
        System.out.println(lock.isLocked());
        Object object = new Student("ashish","kumar", 26);
        Student student = (Student) object;
        System.out.println(student.getfName());
    }

}

class DisplayThread extends  Thread{
    String name;
    ReentrantLock lock;

    public DisplayThread(String name, ReentrantLock lock) {
        this.name = name;
        this.lock = lock;
    }
    public void run(){
        if (lock.tryLock())
        lock.lock();
        // do your taks
        lock.unlock();
    }
}