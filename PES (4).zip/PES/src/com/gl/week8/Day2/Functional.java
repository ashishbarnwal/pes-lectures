package com.gl.week8.Day2;

import com.gl.week4.week5.hashing.Employee;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Functional {
    public static void main(String[] args) {
        String i1 ="ashish";
        String  i2= "ashish";
        System.out.println(i1==i2);
        System.out.println(i1.equals(i2));
        List<Integer> duplicates = Arrays.asList(1,2,3,1,3,4,5,6,4,5);
        int sum = duplicates.stream().distinct().mapToInt(value -> value).sum();
        List<Integer> dob = duplicates.stream().map(value -> value * value).collect(Collectors.toList());


        System.out.println(dob);
        System.out.println(duplicates.stream().count());

        duplicates.stream().distinct().forEach(a-> System.out.print(a));

        List<Integer> list = Arrays.asList();
        Predicate<Integer> p = ( i ) -> i%2==0;
        List nList = list.stream().filter(p).collect(Collectors.toList());
        System.out.println(list);
        System.out.println(nList);
        MyConsumer m = new MyConsumer();
        System.out.println("using consumer");

        nList.stream().forEach(i -> System.out.println(i));
        Set<Employee> set1 = new TreeSet<>((o1, o2) -> o1.getAge()- o2.getAge());

        Supplier m1 = new MySupplier();

        System.out.println("using supplier");

        Integer integer= list.stream().findAny().orElseGet(m1);
        System.out.println(integer);
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
        for (int i:list){
            System.out.println(i);
        }
        Iterator<Integer> it = list.listIterator();
        while (it.hasNext()){
            System.out.println(it.next());
        }

        list.stream().filter(iii -> iii%3==0).forEach(System.out::println);

        Set<Integer> set = new HashSet<>();
        set.addAll(list);

        for (int i:set){
            System.out.println(i);
        }
        Iterator<Integer> i = list.listIterator();
        while (i.hasNext()){
            System.out.println(i.next());
        }

        set.stream().forEach(System.out::println);

       Map<Integer, String> map =new HashMap<>();

       map.put(123, "ashish");
        map.put(133, "Amit");

        map.put(12, "Anurag");
        map.put(23, "ashi");

        System.out.println(map.keySet());
        System.out.println(map.values());

        for (int key: map.keySet()){
            System.out.println(map.get(key));
        }

        for (Map.Entry<Integer, String> entry: map.entrySet()){
            System.out.println(entry.getKey()+" "+entry.getValue());
        }

        Iterator<Integer> itr = map.keySet().iterator();
        while (itr.hasNext()){
            int temp = itr.next();
            System.out.println(temp+" "+map.get(temp));
        }

        Iterator<Map.Entry<Integer, String>> mpItr = map.entrySet().iterator();
        while (mpItr.hasNext()){
            Map.Entry<Integer, String> en =  mpItr.next();
            System.out.println(en.getKey()+" "+en.getValue());
        }

        map.entrySet().stream().filter(o->o.getKey()>5).forEach(obj -> System.out.println(obj.getKey()+" "+obj.getKey()));



        MyInerface mi = new MyInerface() {
            @Override
            public void method(int i, int j) {
                System.out.println("implementation done "+(i+j));
                System.out.println();
                for (int l = 0; l < 5; l++) {

                }
            }
        };

       /* MyInerface mi = (k,j) -> {
            System.out.println("implementation done "+(k+j));
            System.out.println();
            for (int l = 0; l < ; l++) {

            }
        };*/
        mi.method(5,9);

        Runnable r = () ->{
                for (int j = 0; j < 5; j++) {
                    System.out.println(5);
                }
        };
        Thread t = new Thread(r);
        t.start();
    }
}

@FunctionalInterface
interface MyInerface{
    void method(int i, int j);
}

class MyClass implements MyInerface{

    @Override
    public void method(int i, int j) {
        System.out.println("implementaiton done");
    }
}

class MySupplier implements Supplier<Integer>{

    @Override
    public Integer get() {
        return 100;
    }
}

class MyConsumer implements Consumer<Employee>{

    @Override
    public void accept(Employee e) {
        System.out.println(e);
    }
}

class MyPredicate implements Predicate<Integer>{

    @Override
    public boolean test(Integer integer) {
        return integer%2==0;
    }
}