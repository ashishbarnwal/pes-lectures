package com.gl.week8.Day2;

import com.gl.week4.week5.hashing.Employee;

import java.time.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.time.ZoneId.getAvailableZoneIds;

public class SODemo {
    public static void main(String[] args) {
        Employee e1 = new Employee(123,"john","mathew",23,"neeladri road bangalore");
        Employee e2 = new Employee(123,"john","mathew",23,"neeladri road bangalore");
        Employee e3 = new Employee(125,"Nagashree","Illa",26,"bangalore");
        Employee e4 = new Employee(125,"ANagashree","Illa",26,"bangalore");
        Employee e5 = new Employee(128,"swati","kumari",26,"koramangla road bangalore");
        // distinct  filter map  sorted foreach collect skip count

        LocalDate localDate =LocalDate.now();
        System.out.println(localDate);

        LocalTime localTime =LocalTime.now();
        System.out.println(localTime);

        List<String> availableZoneIds = new ArrayList<>(getAvailableZoneIds());

        System.out.println(availableZoneIds.get(0));

        LocalDateTime ldt = LocalDateTime.now();

        System.out.println(ldt.getDayOfMonth());
        System.out.println(ldt.getDayOfYear());

        System.out.println(ldt.getDayOfWeek().getValue());


        // System.out.println(zdt);


        List<Employee> employees = Arrays.asList(e1,e2,e3,e4,e5);
       // employees.stream().sorted().forEach(e-> System.out.println(e));
//        employees.stream().distinct().forEach(a-> System.out.println(a));
//        System.out.println(employees.stream().distinct().count());;

        List<Employee> collect = employees.stream().distinct().limit(2).collect(Collectors.toList());


        List<Integer> lll = Arrays.asList(1,2,3,4,5,6,7,8,9);
        int max = lll.stream().sorted(Comparator.reverseOrder()).skip(8).collect(Collectors.toList()).get(0);
        System.out.println(max);

        System.out.println(collect);


   //     employees.stream().filter(employee -> employee.getAddress().startsWith("b") && employee.getName().startsWith("A")).forEach(System.out::println);


        List<Integer> duplicates = Arrays.asList(1,2,3,1,3,4,5,6,4,5);
        Stream<Integer> stream = duplicates.stream();
        int sum =stream.distinct().mapToInt(value -> value).sum();
        List<Integer> dob = duplicates.stream().map(value -> value * value).collect(Collectors.toList());


    }
}
