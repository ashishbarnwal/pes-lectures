package com.gl.week8;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

public class CharOccurance {
    public static void main(String[] args) {
        String s = "aababbbeecccccfgg"; //
        System.out.println(chars(s));;
    }

    public static String chars(String s){
        Map<Character, Integer> map = new HashMap<>();
        for (char c:s.toCharArray()){
            map.put(c, map.getOrDefault(c,0)+1);
        }

       /* PriorityQueue<Integer> pq = new PriorityQueue<>((aaloo, tamatar) -> tamatar-aaloo);
        for (int i = 0; i < 10; i++) {
            pq.add(i);
        }
        while (!pq.isEmpty()){
            System.out.println(pq.remove());
        }*/

        PriorityQueue<Character> pq = new PriorityQueue<>((o1, o2) -> map.get(o1)-map.get(o2));
        pq.addAll(map.keySet());
        String res= "";
        while (!pq.isEmpty()){
            char temp = pq.remove();
            for (int i = 0; i < map.get(temp); i++) {
                res+=temp;
            }
        }
        return res;
    }

}
