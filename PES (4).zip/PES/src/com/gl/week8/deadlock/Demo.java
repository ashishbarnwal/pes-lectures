package com.gl.week8.deadlock;

public class Demo {

    public static void main(String[] args)
    {
         String R1 = "Resource1";
         String R2 = "Resource2";
        Thread1 T1 = new Thread1(R1,R2);
        Thread1 T2 = new Thread1(R2,R1);
        T1.start();
        T2.start();
    }
}

class Thread1 extends Thread{
    String R1;
    String R2;

    public Thread1(String r1, String r2) {
        R1 = r1;
        R2 = r2;
    }

    public void run(){

        synchronized (R2){
            System.out.println("Thread T1 locked ->   Resource R1");
            synchronized (R1){
                System.out.println("Thread T1 locked -> Resource R2");
            }
        }
    }
}

class Thread2 extends Thread{

    String R1;
    String R2;

    public Thread2(String r1, String r2) {
        R1 = r1;
        R2 = r2;
    }

    public void run(){

        synchronized (R1){
            System.out.println("Thread T1 locked ->   Resource R1");

            synchronized (R2){
                System.out.println("Thread T1 locked -> Resource R2");
            }
        }
    }
}
