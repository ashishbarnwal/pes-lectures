package com.gl.week8.deadlock;

public class PriorityDemo {
    public static void main(String[] args) throws InterruptedException {
        Thread.currentThread().join();
       // Thread.currentThread().setPriority(9);
        DemoThread t = new DemoThread();
        DemoThread.m = Thread.currentThread();
      //  t.setPriority(9);
     //   System.out.println(t.getPriority());
        t.start();
     //   t.join();
        for (int i = 0; i < 10; i++) {
            System.out.println("main"+i);
            Thread.sleep(500);
        }
    }
}

class DemoThread extends Thread{
    static Thread m;
    public void run(){
        try {
            m.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < 10; i++) {
            System.out.println("child"+i);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //System.out.println("my thread");
    }
}