package com.gl.week8.designpatterns;

public class Singleton {

}
