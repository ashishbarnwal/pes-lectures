package com.gl.week8.designpatterns;

public class Builder {
    public static void main(String[] args) {
        Car car = new Car.CarBuilder("TATA", 4, "power", "100 CC")
                .setmusic("Android")
                .setAC("AC")
                .setColour("red").build();

        System.out.println(car);

    }
}

class Car {
    // mandatory
    private String manufacturer;
    private Integer seats;
    private String engine;
    private String steeringWheel;

    // non -mandatory

    private String colour;
    private Integer seatCovers;
    private String music;
    private String AC;

    @Override
    public String toString() {
        return "Car{" +
                "manufacturer='" + manufacturer + '\'' +
                ", seats=" + seats +
                ", engine='" + engine + '\'' +
                ", steeringWheel='" + steeringWheel + '\'' +
                ", colour='" + colour + '\'' +
                ", seatCovers=" + seatCovers +
                ", music='" + music + '\'' +
                ", AC='" + AC + '\'' +
                '}';
    }

    public Car(CarBuilder carBuilder){
        this.manufacturer = carBuilder.manufacturer;
        this.seats = carBuilder.seats;
        this.steeringWheel = carBuilder.steeringWheel;
        this.engine = carBuilder.engine;
        this.colour = carBuilder.colour;
        this.seatCovers = carBuilder.seatCovers;
        this.music = carBuilder.music;
        this.AC = carBuilder.AC;
    }

    public static class CarBuilder {
        // mandatory
        private String manufacturer;
        private Integer seats;
        private String engine;
        private String steeringWheel;

        // non -mandatory

        private String colour;
        private Integer seatCovers;
        private String music;
        private String AC;

        public CarBuilder(String manufacturer, Integer seats, String engine, String steeringWheel) {
            this.manufacturer = manufacturer;
            this.seats = seats;
            this.engine = engine;
            this.steeringWheel = steeringWheel;
        }

        public CarBuilder setColour(String colour) {
            this.colour = colour;
            return this;
        }

        public CarBuilder setSeatCovers(Integer seatCovers) {
            this.seatCovers =seatCovers;
            return this;
        }

        public CarBuilder setmusic(String music) {
            this.music =music;
            return this;
        }

        public CarBuilder setAC(String AC) {
            this.AC = AC;
            return this;
        }

        public Car build() {
            return new Car(this);
        }

    }
}
